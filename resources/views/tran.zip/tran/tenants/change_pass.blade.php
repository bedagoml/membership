@extends('layouts.home')

@section('content')

<div class="content container-fluid">

    <div class="row">
        <div class="col-md-6 offset-md-3">

            <!-- Page Header -->
            <div class="page-header">
                <div class="row">
                    <div class="col-sm-12">
                        <h3 class="page-title">Reset Tenant Password</h3>
                    </div>
                </div>
            </div>
            <!-- /Page Header -->

            @include('includes.messages')

            <form action="{{ route('tenant.updatepassword',$tenant_id)}}" method="POST">
                @csrf
                @method('PUT')

                <div class="form-group">
                    <label>New password</label>
                    <input type="password" class="form-control" name="new_password">
                </div>
                <div class="form-group">
                    <label>Confirm password</label>
                    <input type="password" class="form-control" name="repeat_password">
                </div>
                <div class="submit-section">
                    <button class="btn btn-primary submit-btn" type="submit">Update Password</button>
                </div>
            </form>
        </div>
    </div>




</div>

@endsection